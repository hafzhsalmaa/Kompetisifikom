<?php

use Illuminate\Support\Facades\Route;

// Route::get('/', function () {
//     return view('welcome');
// });

Route::get('/', function () {
    return view('beranda');
});

Route::get('/beranda', function () {
    return view('beranda');
});

Route::get('/tentang', function () {
    return view('tentang');
});

Route::get('/kaprodi', function () {
    return view('ketua-prodi');
});

Route::get('/pengumuman',
    [ App\Http\Controllers\pengumumanController::class, 'list']);

Route::get('/pengumuman/{id}',
    [ App\Http\Controllers\pengumumanController::class, 'detail']);

Route::get('/prestasi',
    [ App\Http\Controllers\prestasiController::class, 'list']);

Route::get('/prestasi/{id}',
    [ App\Http\Controllers\prestasiController::class, 'detail']);

Route::get('/kategori',
    [ App\Http\Controllers\KategoriBeritaController::class, 'list']);

Route::get('/berita',
    [ App\Http\Controllers\BeritaController::class, 'list']);

Route::get('/kategori-berita/{id}',
    [ App\Http\Controllers\BeritaController::class, 'list_kategori']);

Route::get('/berita/{id}',
    [ App\Http\Controllers\BeritaController::class, 'detail']);

Route::get('/kategorikom',
    [ App\Http\Controllers\KategoriKompetisiController::class, 'list']);

Route::get('/kompetisi',
    [ App\Http\Controllers\KompetisiController::class, 'list']);

Route::get('/kategori-kompetisi/{id}',
    [ App\Http\Controllers\KompetisiController::class, 'list_kategori']);

Route::get('/kompetisi/{id}',
    [ App\Http\Controllers\KompetisiController::class, 'detail']);


