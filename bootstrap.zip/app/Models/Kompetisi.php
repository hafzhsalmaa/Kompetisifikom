<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class Kompetisi extends Model
{
    use HasFactory;

    protected $table = 'kompetisi';

    protected $fillable = [
        "kategori_id",
        "judul_kompetisi",
        "konten_kompetisi",
        "gambar_kompetisi",
        "lampiran",
        "lampiran_nama"
    ];

    public function kategori(): BelongsTo
    {
        return $this->belongsTo(KategoriKompetisi::class);
    }

    protected $casts = [
        'lampiran' => 'array',
        'lampiran_nama' => 'array',
    ];

}
