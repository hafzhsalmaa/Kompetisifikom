<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Models\pengumuman;
use Illuminate\View\View;

class pengumumanController extends Controller
{
    public function list() : View
    {
        $data = pengumuman::all();
        return view('pengumuman.list', [ 'data' => $data ]);
    }

    public function detail($id): View
    {
        $data = pengumuman::find($id);
        return view('pengumuman.detail', [ 'data' => $data ]);
    }

}
