<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Models\Kompetisi;
use App\Models\KategoriKompetisi;
use Doctrine\DBAL\Schema\View as SchemaView;
use Illuminate\View\View;

class KompetisiController extends Controller
{
    public function list(): View
    {
        $data = Kompetisi::all();
        return view('kompetisi.list', [ 'data' => $data ]);
    }

    public function list_kategori($id): View
    {
        $data = Kompetisi::where("kategori_id",$id)->get();
        $dataKategori = KategoriKompetisi::find($id);
        return view('kompetisi.kategori', [ 'data' => $data, 'kategori'=>$dataKategori]);
    }

    public function detail($id): View
    {
        $data = Kompetisi::find($id);
        return view('kompetisi.detail', [ 'data' => $data]);
    }
}
