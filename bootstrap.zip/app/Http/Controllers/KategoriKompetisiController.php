<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Models\KategoriKompetisi;
use Illuminate\View\View;

class KategoriKompetisiController extends Controller
{
    public function list(): View
    {
        $data = KategoriKompetisi::all();
        return view('kategori_kompetisi.list', [ 'data' => $data ]);
    }
}
