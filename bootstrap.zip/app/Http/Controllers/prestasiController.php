<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Models\prestasi;
use Illuminate\View\View;
use App\Models\Image;

class prestasiController extends Controller
{
    public function list() : View
    {
        $data = prestasi::all();
        return view('prestasi.list', [ 'data' => $data ]);
    }

    public function detail($id): View
    {
        $data = prestasi::find($id);
        return view('prestasi.detail', [ 'data' => $data ]);
    }

}

