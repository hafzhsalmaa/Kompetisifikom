<?php

namespace App\Filament\Resources\KategoriKompetisiResource\Pages;

use App\Filament\Resources\KategoriKompetisiResource;
use Filament\Actions;
use Filament\Resources\Pages\ListRecords;

class ListKategoriKompetisis extends ListRecords
{
    protected static string $resource = KategoriKompetisiResource::class;

    protected function getHeaderActions(): array
    {
        return [
            Actions\CreateAction::make(),
        ];
    }
}
