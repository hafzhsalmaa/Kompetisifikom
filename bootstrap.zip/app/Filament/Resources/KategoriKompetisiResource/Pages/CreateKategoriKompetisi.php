<?php

namespace App\Filament\Resources\KategoriKompetisiResource\Pages;

use App\Filament\Resources\KategoriKompetisiResource;
use Filament\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreateKategoriKompetisi extends CreateRecord
{
    protected static string $resource = KategoriKompetisiResource::class;
}
