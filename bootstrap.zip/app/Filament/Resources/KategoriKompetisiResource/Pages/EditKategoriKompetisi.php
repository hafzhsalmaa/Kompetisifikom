<?php

namespace App\Filament\Resources\KategoriKompetisiResource\Pages;

use App\Filament\Resources\KategoriKompetisiResource;
use Filament\Actions;
use Filament\Resources\Pages\EditRecord;

class EditKategoriKompetisi extends EditRecord
{
    protected static string $resource = KategoriKompetisiResource::class;

    protected function getHeaderActions(): array
    {
        return [
            Actions\DeleteAction::make(),
        ];
    }
}
