<?php

namespace App\Filament\Resources\KompetisiResource\Pages;

use App\Filament\Resources\KompetisiResource;
use Filament\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreateKompetisi extends CreateRecord
{
    protected static string $resource = KompetisiResource::class;
}
