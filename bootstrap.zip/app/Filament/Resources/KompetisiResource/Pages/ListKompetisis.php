<?php

namespace App\Filament\Resources\KompetisiResource\Pages;

use App\Filament\Resources\KompetisiResource;
use Filament\Actions;
use Filament\Resources\Pages\ListRecords;

class ListKompetisis extends ListRecords
{
    protected static string $resource = KompetisiResource::class;

    protected function getHeaderActions(): array
    {
        return [
            Actions\CreateAction::make(),
        ];
    }
}
