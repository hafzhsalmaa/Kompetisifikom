@extends('layout')

@section('judul','Selamat Datang')

@section('konten')

    <section class="hero">
        <div class="hero-body">
            <p class="title">Selamat Datang</p>
            <p class="subtitle">
                Kompetisi Sistem Informasi - Universitas Duta Bangsa Surkarta
            </p>
        </div>
    </section>

@endsection
