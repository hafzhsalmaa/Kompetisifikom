@extends('layout')

@section('judul', 'Kompetisi')

@section('konten')

    <section class="hero is-success">
        <div class="hero-body">
            <p class="title">Kompetisi</p>
            <p class="subtitle">Program Studi Sistem Informasi</p>
        </div>
    </section>

    <section class="section has-background-primary-soft has-text-primary-soft-invert">

        @foreach ($data as $item)
            <div class="card">
                <div class="card-content">
                    <div class="content">
                        <h2>{{ $item->judul_kompetisi }}</h2>
                        <i>Kategori: {{ $item->kategori->nama_kategori }}</i>
                    </div>
                    <div class=image-container>
                        <center>
                            <img src="{{ Storage::url($item->gambar_kompetisi) }}">
                        </center>
                    </div>
                </div>
                <footer class="card=footer">
                    <a href="/kompetisi/{{ $item->id }}" class="card-footer-item">Selengkapnya</a>
                </footer>
            </div>
        @endforeach

    </section>

@endsection
