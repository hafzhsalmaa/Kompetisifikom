@extends('layout')

@section('judul', 'Kaprodi')

@section('konten')

    <style>
        .header-container {
            position: relative;
            width: 100%;
            height: 130px;
        }

        .header-image {
            width: 100%;
            height: 100%;
            object-fit: cover;
        }

        .header-text {
            position: absolute;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            color: white;
            text-align: left;
            font-size: 2em;
            text-shadow: 2px 2px 4px rgba(0, 0, 0, 0.7);
        }

        .container {}
    </style>

    <div class="column is-full has-background-link has-text-white-bis-is">
        <span class="fa-stack fa-lg">
            <i class="fa fa-phone fa-stack-1x "></i>
        </span>
        <span class="text is-8">+62 876-54235-098</span>
        <span class="fa-stack fa-lg">
            <i class="fa fa-envelope fa-stack-1x"></i>
        </span>
        <span>fikom@udb.ac.id</span>
    </div>

    <div class="column is-full">
        <table class="column is-full">
            <tbody>
                <tr>
                    <td><img class="image" src="/images/logoUDB.png"></td>
                    <td><img class="image" src="/images/garis.svg"></td>
                    <td>&nbsp;</td>
                    <td>&nbsp;</td>
                    <td rowspan="2">
                        <br>
                        <p class="subtitle is-6">FAKULTAS</p>
                        <p class="title is-6">ILMU KOMPUTER</p>
                    </td>
                    <td>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>
                    <td>
                        <br>
                        <div class="navbar-item has-dropdown is-hoverable">
                            <a class="navbar-link ">
                                Beranda
                            </a>
                        </div>
                    </td>
                    <td>
                        <br>
                        <div class="navbar-item has-dropdown is-hoverable">
                            <a class="navbar-link">
                                Info Fakultas
                            </a>
                            <div class="navbar-dropdown">
                                <a class="navbar-item">
                                    About
                                </a>
                                <a class="navbar-item is-selected">
                                    Jobs
                                </a>
                                <a class="navbar-item">
                                    Contact
                                </a>
                                <hr class="navbar-divider">
                                <a class="navbar-item">
                                    Report an issue
                                </a>
                            </div>
                        </div>
                    </td>
                    <td>
                        <br>
                        <div class="navbar-item has-dropdown is-hoverable">
                            <a class="navbar-link">
                                Prodi
                            </a>
                            <div class="navbar-dropdown">
                                <a class="navbar-item">
                                    About
                                </a>
                                <a class="navbar-item is-selected">
                                    Jobs
                                </a>
                                <a class="navbar-item">
                                    Contact
                                </a>
                                <hr class="navbar-divider">
                                <a class="navbar-item">
                                    Report an issue
                                </a>
                            </div>
                        </div>
                    </td>
                    <td>
                        <br>
                        <div class="navbar-item has-dropdown is-hoverable">
                            <a class="navbar-link">
                                Kemahasiswaan
                            </a>
                            <div class="navbar-dropdown">
                                <a class="navbar-item">
                                    About
                                </a>
                                <a class="navbar-item is-selected">
                                    Jobs
                                </a>
                                <a class="navbar-item">
                                    Contact
                                </a>
                                <hr class="navbar-divider">
                                <a class="navbar-item">
                                    Report an issue
                                </a>
                            </div>
                        </div>
                    </td>
                    <td>
                        <br>
                        <div class="navbar-item has-dropdown is-hoverable">
                            <a class="navbar-link">
                                Tentang
                            </a>
                            <div class="navbar-dropdown">
                                <a class="navbar-item">
                                    About
                                </a>
                                <a class="navbar-item is-selected">
                                    Jobs
                                </a>
                                <a class="navbar-item">
                                    Contact
                                </a>
                                <hr class="navbar-divider">
                                <a class="navbar-item">
                                    Report an issue
                                </a>
                            </div>
                        </div>
                    </td>
                    <td>
                        <br>
                        <div class="navbar-item has-dropdown is-hoverable">
                            <a class="navbar-link">
                                Artikel IPTEK
                            </a>
                            <div class="navbar-dropdown">
                                <a class="navbar-item">
                                    About
                                </a>
                                <a class="navbar-item is-selected">
                                    Jobs
                                </a>
                                <a class="navbar-item">
                                    Contact
                                </a>
                                <hr class="navbar-divider">
                                <a class="navbar-item">
                                    Report an issue
                                </a>
                            </div>
                        </div>
                    </td>
                </tr>
            </tbody>
        </table>
    </div>

    <div class="header-container">
        <img class="header-image" src="{{ asset('images/header7.jpg') }}" alt="Program Studi">
        <div class="header-text">
            Program Studi
        </div>
    </div>

    <section class="section has-background-light has-text-link">
        <div class="container text-center">
            <center>
                <figure class="image">
                    <img class="is-rounded" src="/images/prodi3.png"
                        style="object-fit: cover; width: 300px; height: 300px;">
                </figure>
                <div class="content"></div>
                <div class="content is-medium">
                    <h1><strong class="has-text-link-85">Eko Purwanto, M.Kom<strong></h1>
                    <h6><strong class="has-text-link-85">Ketua Program Studi S1 - Sistem Informasi</strong></h6>
                </div>
            </center>
        </div>
        <div class="column"></div>
        <center>
            <div class="columns has-text-link-85">
                <div class="column">
                    <span class="fa-stack fa-2x">
                        <i class="fa fa-university fas fa-2x "></i>
                    </span>
                </div>
                <div class="column">
                    <span class="fa-stack fa-2x">
                        <i class="fa fa-medal fas fa-2x "></i>
                    </span>
                </div>
            </div>
            <div class="columns">
                <div class="column">
                    <div class="content is-medium">
                        <h2><strong class="has-text-link-85">Fakultas</strong></h2>
                        <h5><strong class="has-text-link-85">Fakultas Ilmu Komputer</strong></h5>
                    </div>
                </div>
                <div class="column">
                    <div class="content is-medium">
                        <h2><strong class="has-text-link-85">Nama Program Studi</strong></h2>
                        <h5><strong class="has-text-link-85">S1 - Sistem Informasi</strong></h5>
                    </div>
                </div>
            </div>
        </center>
        <div class=column></div>
        <div class="container text-center">
            <div class="content">
                <center>
                    <h2><strong>Biografi<strong></h2>
                </center>
                <div class=box>
                    <p> Eko Purwanto, M.Kom Lahir di Klaten, 27 Juni 1984. Lulus S1 Sistem Informasi STMIK Duta
                        Bangsa Surakarta Tahun 2008, lulus S2 di Program Magister Teknik Informatika Konsentrasi
                        Sistem Informasi AMIKOM Yogyakarta tahun 2013. Saat ini adalah dosen tetap Fakultas Ilmu
                        Komputer Universitas Duta Bangsa Surakarta mengampu matakuliah Sistem Informasi Eksekutif,
                        Desain dan Manajemen Jaringan Komputer dan Pemrograman Basis Data. Pernah menjadi dosen tamu
                        di program studi D3-Manajemen Informatika Politeknik Indonusa Surakarta. Aktif menulis
                        artikel jurnal dan menjadi narasumber dalam beberapa seminar dan pelatihan tentang teknologi
                        informasi. Saat ini sedang melanjutkan pendidikan S-3 di Universitas Kuala Lumpur (UniKL)
                        Malaysia.
                    </p>
                </div>
            </div>
        </div>

        <div class=column></div>
        <div class="containe text-center">
            <div class="content">
                <center>
                    <h2><strong>Deskripsi Program Studi<strong></h2>
                </center>
                <div class=box>
                    <p> Fakultas Ilmu Komputer Universitas Duta Bangsa Surakarta salah satu Program Studi yang dimiliki
                        adalah S1-Sistem Informasi dengan legalitas berdasarkan SK 0252/SK/BAN-PT/Akred/S/IV/2016
                        Program studi Sistem Informasi berdiri ditengah-tengah perkembangan Teknologi yang begitu pesat
                        yang ditandai pada perubahan-perubahan baik dalam kehidupan masyarakat, dunia bisnis,
                        pemerintahan bahkan dunia pendidikan. Program Studi Sistem Informasi mempunyai tantangan dan
                        peluang untuk mempersiapkan sumber daya manusia yang dapat bersaing dan beradaptasi terhadap
                        perkembangan ilmu pengetahuan dan IPTEK. Program studi Sistem Informasi menjadi solusi bagi
                        stakholder guna menjawab tantangan dan peluang yang ada.
                    </p>
                    <p>Program Studi Sistem Informasi Fakultas Ilmu Komputer Universitas Duta Bangsa Surakarta berada di
                        tengah Kota Surakarta mampu mendorong semangat masyarakat untuk melanjutkan pendidikan pada
                        jenjang lebih tinggi yang memiliki kompetensi dibidang Analis Sistem Bisnis (Business System
                        Analyst), Perancang Sistem (System Designer), Programmer, Database Designer, Database
                        Administrator dan Technopreneur. Program Studi Sistem Informasi memiliki komitmen untuk
                        mewujudkan kompetensi mahasiswa telah diwujudkan melalui pengelolaan program studi berbasis
                        instrumen akreditasi, disain kurikulum mengacu pada standar pembelajaran Nasional Pendidikan
                        Tinggi (SN_DIKTI), KKNI level 6 dan rumusan kurikulum pendidikan tinggi oleh Asosiasi Pendidikan
                        Tinggi Informatika dan Komputer (APTIKOM).
                    </p>
                    <p>Untuk mempersiapkan karir mahasiswa, upaya program studi SI antara lain merumuskan dan menetapkan
                        profil lulusan (Analis Sistem Bisnis (Business System Analyst), Perancang Sistem (System
                        Designer), Programmer, Database Designer, Database Administrator dan Technopreneur) yang
                        didukung capaian pembelajaran (sikap, pengetahuan, ketrampilan umum dan ketrampilan khusus),
                        beban studi mahasiswa harus menyelesaikan 149 sks yang tersebar di semester 1 sampai dengan
                        semester 8 dan dapat ditempuh selama 4 tahun, konsep implementasi kurikulum 6 semester
                        pelaksanaan perkuliahan dikampus, 2 semester mahasiswa menerapkan capaian pembelajaran melalui
                        kegiatan Merdeka Belajar atau praktik kerja lapangan durasi waktu 3-6 bulan dan menghasilkan
                        karya inovasi siap pakai melalui skripsi, metode pembelajaran sudah didukung 70% mata kuliah
                        berbasis projek dan diakselerasikan dengan gerakan mahasiswa berprestasi/karya inovasi,
                        seminar/workshop bersifat wajib, sertifikasi kompetensi menjadi syarat kelulusan mahasiswa,
                        produktifitas kegiatan mahasiswa yang tertuang dalam Surat Keterangan Pendamping Ijazah (SKPI).
                    </p>
                </div>
            </div>
        </div>

        <div class=column></div>
        <div class="container text-center">
            <div class="content">
                <center>
                    <h2><strong>Tujuan<strong></h2>
                </center>
                <div class=box>
                    <p>1. Menghasilkan lulusan Program Studi Sistem Informasi yang memiliki kemampuan manajemen basis
                        data dan sistem informasi enterprise yang dapat bersaing secara nasional.
                    </p>
                    <p>2. Menghasilkan lulusan yang mampu mengikuti perkembangan teknologi informasi untuk memberikan
                        solusi bisnis maupun mengembangkan kewirausahaan berbasis teknologi.
                    </p>
                    <p>3. Menghasilkan lulusan yang profesional yang memiliki moral, etika, kepribadian dan akhlakul
                        karimah serta memiliki kemauan untuk terus belajar dan mengembangkan diri.
                    </p>
                    <p>4. Memberikan kontribusi kepada masyarakat melalui pengembangan basis data dan sistem informasi
                        enterprise yang tepat guna.
                    </p>
                    <p>5. Memperluas jaringan kemitraan untuk memdapatkan peluang bagi lulusan agar dapat bekerja di
                        instansi mitra secara profesional dan peningkatan kualitas program studi.
                    </p>
                </div>
            </div>
        </div>

        <div class="columns">
            <div class="column is-half">
                <div class="content">
                    <center>
                        <h2><strong>Visi<strong></h2>
                    </center>
                    <div class="box">
                        <p>Menjadi Program Studi Unggulan Tingkat Global Pada Tahun 2038 Di Bidang Pengembang Sistem
                            Informasi Enterprise dan Technopreneur.</p>
                    </div>
                </div>
            </div>
            <div class="column">
                <div class="content">
                    <center>
                        <h2><strong>Misi<strong></h2>
                    </center>
                    <div class="box">
                        <p>1. Menyelenggarakan pendidikan secara profesional, terencana dan terintegrasi yang tercermin pada
                            kurikulum pendidikan tinggi yang unik berbasis kewirausahaan dan bisnis dalam rangka
                            menghasilkan lulusan yang mandiri, inovatif, visioner, beriman dan berorientasi global.
                        </p>
                        <p>2. Melakukan kegiatan penelitian inovatif dan kreatif yang unggul dibidang basis data dan sistem
                            informasi enterprise
                        </p>
                        <p>3.Melakukan kegiatan Pengabdian Kepada Masyarakat melalui produk inovasi tepat guna untuk
                            kesejahteraan masyarakat.
                        </p>
                        <p>4.Membangun kemitraan dengan pengguna lulusan dan lembaga pendidikan lain untuk menciptakan
                            keunggulan bersaing
                        </p>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <div class="column is-full">
        <table class="column is-full" border="0">
            <tbody>
                <tr>
                    <td><img class="image" src="/images/logoUDB.png"></td>
                    <td><img class="image" src="/images/garis.svg"></td>
                    <td>&nbsp;&nbsp;&nbsp;</td>
                    <td>
                        <br>
                        <p class="subtitle is-6">FAKULTAS</p>
                        <p class="title is-6">ILMU KOMPUTER</p>
                    </td>
                    <td>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>
                    <td>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>
                    <td rowspan="3" colspan="3">
                        <p class="subtitle is-6"><b>Tentang Fakultas</b></p>
                        <p class="subtitle is-6">Visi Misi</p>
                        <p class="subtitle is-6">Sejarah</p>
                        <p class="subtitle is-6">Struktur</p>
                        <p class="subtitle is-6">Akreditasi</p>
                        <p class="subtitle is-6">Kalender Akademik</p>
                    </td>
                    <td>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>
                    <td>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>
                    <td rowspan="3">
                        <p class="subtitle is-6"><b>Kontak</b></p>
                        <ul>
                            <li><i class="fas fa-envelope fa fa-1x "></i>
                                <span>fikom@udb.ac.id</span>
                            </li>
                            <li><i class="fas fa-phone fa fa-1x "></i>
                                <span>(0271) 98765</span>
                            </li>
                            <li><i class="fa-solid fa-map-marker-alt fa fa-1x "></i>
                                <span>Jl. Bhayangkara No.55, Tipes, Kec. Serengan, Kota Surakarta, Jawa Tengah 57154</span>
                            </li>
                        </ul>
                    </td>
                </tr>
                <tr>
                    <td colspan="9"><i>"The Global Entrepreneur University"</i></td>
                </tr>
                <tr>
                    <td colspan="9">
                        <span class="fa-stack fa-2x">
                            <i class="fa-brands fa-youtube fab fa-1x "></i>
                        </span>
                        <span class="fa-stack fa-2x">
                            <i class="fa-brands fa-instagram fab fa-1x "></i>
                        </span>
                        <span class="fa-stack fa-2x">
                            <i class="fa-brands fa-twitter fab fa-1x "></i>
                        </span>
                        <span class="fa-stack fa-2x">
                            <i class="fa-brands fa-facebook fab fa-1x "></i>
                        </span>
                    </td>
                </tr>
            </tbody>
        </table>
    </div>

    <div class="column is-full has-background-link has-text-white-bis-is">
        <p><center>Fakultas Ilmu Komputer Universitas Duta Bagsa <i class="fas fa-copyright fas fa-1x"></i> 2021 - <i>The Global Entrepreneur University </i></center></p>
    </div>



@endsection
