<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>@yield('judul') | KOMPETISI </title>
    <link rel="stylesheet" href="/bulma/css/bulma.min.css">
    <link rel="stylesheet" href="/fontawesome/css/all.min.css">
</head>
<body>
    <div class="container">

        <nav class="navbar" role="navigation" aria-label="main navigation">
            <div class="navbar-brand">
                <a class="navbar-item" href="/">
                    <b>KOMPETISI</b>
                </a>

                <a role="button" class="navbar-burger" aria-label="menu" aria-expended="false" data-target="navbarSIFIKOM">
                    <span aria-hidden="true"></span>
                    <span aria-hidden="true"></span>
                    <span aria-hidden="true"></span>
                    <span aria-hidden="true"></span>
                </a>
            </div>

            <div id="navbarSIFIKOM" class="navbar-menu">
                <div class="navbar-start">
                    <a class="navbar-item" href="/">Beranda</a>
                    <a class="navbar-item" href="/tentang">Tentang</a>
                    <a class="navbar-item" href="/kategorikom">Kategori Kompetisi</a>
                    <a class="navbar-item" href="/kompetisi">Kompetisi</a>
                    <a class="navbar-item" href="/prestasi">Prestasi</a>
                    <a class="navbar-item" href="/pengumuman">Pengumuman</a>
                </div>
            </div>
        </nav>
        @yield('konten')
    </div>

    <script type="text/javascript" src="/js/jquery-3.7.1.min.js"></script>

    <script type="text/javascript">
        $(document).ready(function() {

            $(".navbar-burger").click(function() {

                $(".navbar-burger").toggleClass("is-active");
                $(".navbar-menu").toggleClass("is-active");

            });
        });

    </script>

</body>
</html>
