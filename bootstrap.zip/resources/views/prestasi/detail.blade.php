@extends('layout')

@section('judul', $data->judul_prestasi)

@section('konten')

    <section class="hero is-success">
        <div class="hero-body">
            <p class="title">Prestasi</p>
            <p class="subtitle">
                {{ $data->judul_prestasi }}
            </p>
        </div>
    </section>

    <section class="section has-background-primary-soft has-text-primary-soft-invert">
        <div class="card">
            <div class="card-content">
                <div class="content">
                    {{ $data->deskripsi_prestasi }}
                    <div class="container">
                        <h1 class="title">{{ $data->title }}</h1><br>
                        <div class="image-container">
                            <center>
                                <img src={{ $data->foto }}>
                            </center>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <a href="/prestasi" class="button is-info">Kembali</a>

    </section>

@endsection
