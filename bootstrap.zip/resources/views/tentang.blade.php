@extends('layout')

@section('judul', 'tentang')

@section('konten')

    <section class="hero has-background-success">
        <div class="hero-body">
            <p class="title">Tentang Kompetisi Mahasiswa</p>
            <p class="subtitle">
                Program Studi Sistem Informasi
            </p>
        </div>
    </section>

    <section class="section has-text-primary-soft-invert">

        <div class="columns">
            <div class="column">

                <table class="table">
                    <tr>
                        <td>🎯 Deskripsi Tujuan Kompetisi Akademik</td>
                    </tr>
                    <tr>
                        <td>
                            <p>
                                Kompetisi Akademik SI-FIKOM merupakan wadah pengembangan potensi, kreativitas, dan daya
                                saing
                                mahasiswa Fakultas Ilmu Komunikasi Universitas Duta Bangsa Surakarta dalam bidang akademik.
                                Program ini dirancang untuk mendorong mahasiswa agar aktif berpartisipasi dalam kegiatan
                                ilmiah
                                seperti lomba karya tulis, debat, inovasi teknologi, desain poster ilmiah, dan lain-lain.
                            </p>
                            <br>
                            <p>Tujuan utama dari kegiatan ini adalah untuk:</p>

                            <ul>
                                <li>1. Menumbuhkan semangat berkompetisi secara sehat di lingkungan akademik.</li>
                                <li>2. Meningkatkan kemampuan berpikir kritis, analitis, dan komunikatif mahasiswa.</li>
                                <li>3. Menjadi sarana bagi mahasiswa untuk menyalurkan minat dan bakatnya di bidang
                                    akademik.</li>
                                <li>4. Meningkatkan eksistensi mahasiswa FIKOM di tingkat regional maupun nasional.</li>
                            </ul>
                        </td>
                    </tr>
                </table>
            </div>
        </div>
        <div class="columns">
            <div class="column">

                <table class="table">
                    <tr>
                        <td>🌟 Visi</td>
                    </tr>
                    <tr>
                        <td>
                            <p>
                                Menjadi pusat pengembangan kompetisi akademik mahasiswa FIKOM yang unggul, inovatif, dan
                                berdaya saing nasional.
                            </p>
                        </td>
                    </tr>
                </table>
            </div>
        </div>
        <div class="columns">
            <div class="column">

                <table class="table">
                    <tr>
                        <td>📌 Misi</td>
                    </tr>
                    <tr>
                        <td>
                             <ul>
                                <li>1. Menyediakan platform kompetitif yang mendukung pengembangan kemampuan akademik mahasiswa.</li>
                                <li>2. Mendorong kolaborasi antar mahasiswa dalam menciptakan karya ilmiah yang bermutu.</li>
                                <li>3. Membangun budaya akademik yang kompetitif, etis, dan produktif di lingkungan kampus.</li>
                                <li>4. Memberikan apresiasi dan publikasi terhadap prestasi mahasiswa.</li>
                                <li>5. Menyediakan sistem informasi yang terintegrasi dan transparan untuk mendukung pelaksanaan kompetisi akademik.</li>
                            </ul>
                        </td>
                    </tr>
                </table>
            </div>
        </div>
    </section>

@endsection
