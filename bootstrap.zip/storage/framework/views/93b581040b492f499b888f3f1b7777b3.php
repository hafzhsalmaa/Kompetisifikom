<?php $__env->startSection('judul', $data->judul_pengumuman ); ?>

<?php $__env->startSection('konten'); ?>

<section class="hero is-success">
    <div class="hero-body">
        <p class="title">Pengumuman</p>
        <p class="subtitle">
            <?php echo e($data->judul_pengumuman); ?>

        </p>
    </div>
</section>

<section class="section has-background-primary-soft has-text-primary-soft-invert">
        <div class="card">
            <div class="card-content">
                <div class="content">
                    <?php echo e($data->konten_pengumuman); ?>

                </div>
            </div>
        </div>

        <a href="/pengumuman" class="button is-info">Kembali</a>

</section>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\A SEMESTER 4\si-fikom\resources\views/pengumuman/detail.blade.php ENDPATH**/ ?>