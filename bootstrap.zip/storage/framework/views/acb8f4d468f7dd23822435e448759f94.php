<?php $__env->startSection('judul', $data->judul_kompetisi); ?>

<?php $__env->startSection('konten'); ?>

    <section class="hero is-success">
        <div class="hero-body">
            <p class="title"><?php echo e($data->judul_kompetisi); ?></p>
            <p class="subtitle">Kategori: <?php echo e($data->kategori->nama_kategori); ?></p>
        </div>
    </section>

    <section class="section has-background-primary-soft has-text-primary-soft-invert">

        <div class="card">
            <div class="card-content">
                <div class="content">
                    <?php echo e($data->konten_kompetisi); ?>

                </div>
                <div class=image-container>
                    <center>
                        <img src="<?php echo e(Storage::url($data->gambar_kompetisi)); ?>">
                    </center>
                </div>
                <div class=image-container>
                    <?php $__currentLoopData = $data->lampiran; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lampiran): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <iframe src="<?php echo e(Storage::url($lampiran)); ?>" width="100%" height="600px"></iframe>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </div>

        <a href="/kompetisi" class="button is-info">Kembali</a>

    </section>



<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\A SEMESTER 4\si-fikom\resources\views/kompetisi/detail.blade.php ENDPATH**/ ?>