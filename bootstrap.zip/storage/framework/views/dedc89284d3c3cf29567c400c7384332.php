<?php $__env->startSection('judul', $data->judul_prestasi); ?>

<?php $__env->startSection('konten'); ?>

    <section class="hero is-success">
        <div class="hero-body">
            <p class="title">Prestasi</p>
            <p class="subtitle">
                <?php echo e($data->judul_prestasi); ?>

            </p>
        </div>
    </section>

    <section class="section has-background-primary-soft has-text-primary-soft-invert">
        <div class="card">
            <div class="card-content">
                <div class="content">
                    <?php echo e($data->deskripsi_prestasi); ?>

                    <div class="container">
                        <h1 class="title"><?php echo e($data->title); ?></h1><br>
                        <div class="image-container">
                            <center>
                                <img src=<?php echo e($data->foto); ?>>
                            </center>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <a href="/prestasi" class="button is-info">Kembali</a>

    </section>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\A SEMESTER 4\si-fikom\resources\views/prestasi/detail.blade.php ENDPATH**/ ?>