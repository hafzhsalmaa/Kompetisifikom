<?php $__env->startSection('judul', 'Kategori Kompetisi'); ?>

<?php $__env->startSection('konten'); ?>

    <section class="hero is-success">
        <div class="hero-body">
            <p class="title">Kategori Kompetisi</p>
            <p class="subtitle">Program Studi Sistem Informasi</p>
        </div>
    </section>

    <section class="section has-background-primary-soft has-text-primary-soft-invert">

        <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="card">
                <div class="card-content">
                    <div class="content">
                        <?php echo e($item->nama_kategori); ?>

                    </div>
                </div>
                <footer class="card=footer">
                    <a href="/kategori-kompetisi/<?php echo e($item->id); ?>" class="card-footer-item">Selengkapnya</a>
                </footer>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    </section>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\A SEMESTER 4\si-fikom\resources\views/kategori_kompetisi/list.blade.php ENDPATH**/ ?>